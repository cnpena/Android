//Kitchen Timer: Countdown Kitchen timer. Allows the user to set a time using the plus and minus buttons.
//Press START to start the timer and STOP to stop the timer. Save times by pressing the START button.
//Timer only saves times after pressing the + and - buttons and doesn't save duplicate times.
//Developed on the Google Pixel so if it looks really off, try testing on a Pixel :)

package com.dealfaro.luca.KitchenTImer;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    static final private String LOG_TAG = "test2017app1";

    // Counter for the number of seconds.
    private int seconds = 0;
    int button1Seconds;
    int button2Seconds;
    int button3Seconds;
    boolean changedTime;

    // Countdown timer.
    private CountDownTimer timer = null;

    // One second.  We use Mickey Mouse time.
    private static final int ONE_SECOND_IN_MILLIS = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayTime();
    }

    // ACTION: Plus button clicked, adds 60 seconds to the timer
    public void onClickPlus(View v) {
        seconds += 60;
        displayTime();
        changedTime = true;
    }

    // ACTION: Minus button clicked, subtracts 60 seconds to the timer
    public void onClickMinus(View v) {
        seconds = Math.max(0, seconds - 60);
        displayTime();
        changedTime = true;
    }

    // ACTION: Reset (0) button clicked, resets seconds to 0
    public void onReset(View v) {
        seconds = 0;
        cancelTimer();
        displayTime();
        changedTime = false;
    }

    // quickStart: used to start the timer when the user clicks a saved time.
    public void quickStart(){
        changedTime = false;
        if (seconds == 0) {
            cancelTimer();
        }
        if (timer == null) {
            // We create a new timer.
            timer = new CountDownTimer(seconds * ONE_SECOND_IN_MILLIS, ONE_SECOND_IN_MILLIS) {
                @Override
                public void onTick(long millisUntilFinished) {
                    //Log.d(LOG_TAG, "Tick at " + millisUntilFinished);
                    seconds = Math.max(0, seconds - 1);
                    displayTime();
                }

                @Override
                public void onFinish() {
                    seconds = 0;
                    timer = null;
                    displayTime();
                }
            };
            timer.start();
        }
    }

    // ACTION: First button clicked, resets the timer to the time shown on the button
    public void onClickButton1(View v){
        seconds = button1Seconds;
        cancelTimer();
        displayTime();
        quickStart();
    }

    // ACTION: Second button clicked, resets the timer to the time shown on the button
    public void onClickButton2(View v){
        seconds = button2Seconds;
        cancelTimer();
        displayTime();
        quickStart();
    }

    // ACTION: Third button clicked, resets the timer to the time shown on the button
    public void onClickButton3(View v){
        seconds = button3Seconds;
        cancelTimer();
        displayTime();
        quickStart();
    }

    public void onClickStart(View v) {
        if(changedTime) {
            updateButton();
            changedTime = false;
        }
        if (seconds == 0) {
            cancelTimer();
        }
        if (timer == null) {
            // We create a new timer.
            timer = new CountDownTimer(seconds * ONE_SECOND_IN_MILLIS, ONE_SECOND_IN_MILLIS) {
                @Override
                public void onTick(long millisUntilFinished) {
                    //Log.d(LOG_TAG, "Tick at " + millisUntilFinished);
                    seconds = Math.max(0, seconds - 1);
                    displayTime();
                }

                @Override
                public void onFinish() {
                    seconds = 0;
                    timer = null;
                    displayTime();
                }
            };
            timer.start();
        }
    }

    public void onClickStop(View v) {
        cancelTimer();
        displayTime();
    }

    //updateButton: shifts the times stored on the buttons from left to right as the user presses start
    public void updateButton(){
        if(seconds == button1Seconds || seconds == button2Seconds || seconds == button3Seconds){
            return;
        }
        //Button 1
        Button firstButton = (Button)findViewById(R.id.button1);
        int temp = button1Seconds; //use temp variable to shift
        int m = seconds / 60; //get minutes, seconds displayed when the user pressed start
        int s = seconds % 60;
        firstButton.setText(String.format("%d:%02d", m, s));
        button1Seconds = seconds;

        //Button 2
        Button secondButton = (Button)findViewById(R.id.button2);
        int temp2 = button2Seconds;
        m = temp / 60;
        s = temp % 60;
        secondButton.setText(String.format("%d:%02d", m, s));
        button2Seconds = temp;

        //Button 3
        Button thirdButton = (Button)findViewById(R.id.button3);
        m = temp2 / 60;
        s = temp2 % 60;
        thirdButton.setText(String.format("%d:%02d",m,s));
        button3Seconds = temp2;
    }

    private void cancelTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    // Updates the time display.
    private void displayTime() {
       // Log.d(LOG_TAG, "Displaying time " + seconds);
        TextView v = (TextView) findViewById(R.id.display);
        int m = seconds / 60;
        int s = seconds % 60;
        v.setText(String.format("%d:%02d", m, s));
        // Manages the buttons.
        Button stopButton = (Button) findViewById(R.id.button_stop);
        Button startButton = (Button) findViewById(R.id.button_start);
        startButton.setEnabled(timer == null && seconds > 0);
        stopButton.setEnabled(timer != null && seconds > 0);
    }
}
